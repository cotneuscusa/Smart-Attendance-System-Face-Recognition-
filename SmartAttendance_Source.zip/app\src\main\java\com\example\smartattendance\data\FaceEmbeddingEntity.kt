package com.example.smartattendance.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "face_embeddings",
    foreignKeys = [
        ForeignKey(
            entity = StudentEntity::class,
            parentColumns = ["studentId"],
            childColumns = ["studentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["studentId"]),
        Index(
            value = ["studentId", "sampleIndex"],
            unique = true
        )
    ]
)
data class FaceEmbeddingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val studentId: String,

    val sampleIndex: Int,

    val embedding: ByteArray,

    val createdAt: Long = System.currentTimeMillis()
)