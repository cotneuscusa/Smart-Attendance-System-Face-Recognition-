package com.example.smartattendance

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun RegistrationScreen(
    onStartCapture: (String, String) -> Unit,
    onBack: () -> Unit,
) {
    var name by remember {
        mutableStateOf("")
    }

    var studentId by remember {
        mutableStateOf("")
    }

    var errorMessage by remember {
        mutableStateOf("")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
    ) {

        Text(
            text = "register student",
            style = MaterialTheme.typography.headlineMedium,
        )

        Spacer(
            modifier = Modifier.height(24.dp),
        )

        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
                errorMessage = ""
            },
            label = {
                Text("student name")
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        OutlinedTextField(
            value = studentId,
            onValueChange = {
                studentId = it
                errorMessage = ""
            },
            label = {
                Text("student id")
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        Text(
            text = "Privacy Notice: Face photos are processed locally on-device to generate secure cryptographic face signatures (embeddings) and are immediately deleted. No raw face photos are stored.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        if (errorMessage.isNotEmpty()) {
            Text(
                text = errorMessage,
                color = MaterialTheme.colorScheme.error,
            )

            Spacer(
                modifier = Modifier.height(16.dp),
            )
        }

        Button(
            onClick = {
                val cleanedName = name.trim()
                val cleanedStudentId = studentId.trim()

                when {
                    cleanedName.isEmpty() -> {
                        errorMessage = "enter the student's name"
                    }

                    cleanedStudentId.isEmpty() -> {
                        errorMessage = "enter the student's id"
                    }

                    else -> {
                        onStartCapture(
                            cleanedName,
                            cleanedStudentId,
                        )
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("start face capture")
        }

        Spacer(
            modifier = Modifier.height(12.dp),
        )

        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("back")
        }
    }
}
