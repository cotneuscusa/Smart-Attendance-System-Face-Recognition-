package com.example.smartattendance

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.File
import java.util.concurrent.Executors

@ExperimentalGetImage
@Composable
fun CameraScreen(
    studentName: String,
    studentId: String,
    onSamplesComplete: (List<String>) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val activity = context as ComponentActivity

    var cameraPermissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA,
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    var faceCount by remember {
        mutableIntStateOf(0)
    }

    var faceBoxes by remember {
        mutableStateOf<List<Rect>>(emptyList())
    }

    var capturedSamples by remember {
        mutableStateOf<List<String>>(emptyList())
    }

    var isCapturing by remember {
        mutableStateOf(value = false)
    }

    var statusMessage by remember {
        mutableStateOf("")
    }

    var imageCapture by remember {
        mutableStateOf<ImageCapture?>(null)
    }

    val permissionLauncher =
        rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) { granted ->
            cameraPermissionGranted = granted
        }

    val cameraExecutor = remember {
        Executors.newSingleThreadExecutor()
    }

    val detector = remember {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(
                FaceDetectorOptions.PERFORMANCE_MODE_FAST
            )
            .setLandmarkMode(
                FaceDetectorOptions.LANDMARK_MODE_NONE
            )
            .setClassificationMode(
                FaceDetectorOptions.CLASSIFICATION_MODE_NONE
            )
            .build()

        FaceDetection.getClient(options)
    }

    DisposableEffect(Unit) {
        onDispose {
            cameraExecutor.shutdown()
            detector.close()
        }
    }

    if (!cameraPermissionGranted) {

        LaunchedEffect(Unit) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("camera permission is required")

            Button(
                onClick = {
                    permissionLauncher.launch(Manifest.permission.CAMERA)
                },
                modifier = Modifier.padding(top = 16.dp)
            ) {
                Text("allow camera")
            }

            Button(
                onClick = onBack,
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Text("back")
            }
        }

        return
    }

    Box(
        modifier = Modifier.fillMaxSize()
    ) {

        AndroidView(
            factory = { currentContext ->

                val previewView = PreviewView(currentContext)

                val cameraProviderFuture =
                    ProcessCameraProvider.getInstance(currentContext)

                cameraProviderFuture.addListener(
                    {
                        val cameraProvider =
                            cameraProviderFuture.get()

                        val preview = Preview.Builder()
                            .build()
                            .also {
                                it.surfaceProvider =
                                    previewView.surfaceProvider
                            }

                        val newImageCapture =
                            ImageCapture.Builder()
                                .setCaptureMode(
                                    ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
                                )
                                .build()

                        imageCapture = newImageCapture

                        val imageAnalysis =
                            ImageAnalysis.Builder()
                                .setBackpressureStrategy(
                                    ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
                                )
                                .build()

                        imageAnalysis.setAnalyzer(
                            cameraExecutor
                        ) { imageProxy ->

                            val mediaImage = imageProxy.image

                            if (mediaImage == null) {
                                imageProxy.close()
                                return@setAnalyzer
                            }

                            val rotation =
                                imageProxy.imageInfo.rotationDegrees

                            val imageWidth =
                                if ((rotation == 0) || (rotation == 180)) {
                                    imageProxy.width
                                } else {
                                    imageProxy.height
                                }

                            val imageHeight =
                                if ((rotation == 0) || (rotation == 180)) {
                                    imageProxy.height
                                } else {
                                    imageProxy.width
                                }

                            val image = InputImage.fromMediaImage(
                                mediaImage,
                                rotation
                            )

                            detector.process(image)
                                .addOnSuccessListener { faces ->

                                    val boxes = faces.map { face ->
                                        val box = face.boundingBox

                                        mapFaceBox(
                                            left = box.left.toFloat(),
                                            top = box.top.toFloat(),
                                            right = box.right.toFloat(),
                                            bottom = box.bottom.toFloat(),
                                            imageWidth = imageWidth.toFloat(),
                                            imageHeight = imageHeight.toFloat(),
                                            viewWidth = previewView.width.toFloat(),
                                            viewHeight = previewView.height.toFloat()
                                        )
                                    }

                                    faceCount = faces.size
                                    faceBoxes = boxes
                                }
                                .addOnFailureListener {
                                    faceCount = 0
                                    faceBoxes = emptyList()
                                }
                                .addOnCompleteListener {
                                    imageProxy.close()
                                }
                        }

                        val cameraSelector =
                            CameraSelector.DEFAULT_FRONT_CAMERA

                        try {
                            cameraProvider.unbindAll()

                            cameraProvider.bindToLifecycle(
                                activity,
                                cameraSelector,
                                preview,
                                imageAnalysis,
                                newImageCapture
                            )

                        } catch (exception: Exception) {
                            exception.printStackTrace()
                        }
                    },
                    ContextCompat.getMainExecutor(currentContext)
                )

                previewView
            },
            modifier = Modifier.fillMaxSize()
        )

        Canvas(
            modifier = Modifier.fillMaxSize()
        ) {
            faceBoxes.forEach { box ->

                drawRect(
                    color = Color.Green,
                    topLeft = box.topLeft,
                    size = box.size,
                    style = Stroke(
                        width = 6f,
                        cap = StrokeCap.Round
                    )
                )
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text(
                text = "$studentName • id: $studentId",
                color = Color.White,
                modifier = Modifier
                    .background(
                        Color.Black.copy(alpha = 0.65f)
                    )
                    .padding(
                        horizontal = 16.dp,
                        vertical = 8.dp
                    )
            )

            Text(
                text = "sample ${capturedSamples.size} / 3",
                color = Color.White,
                modifier = Modifier
                    .background(
                        Color.Black.copy(alpha = 0.65f)
                    )
                    .padding(
                        horizontal = 16.dp,
                        vertical = 8.dp
                    )
            )

            Text(
                text = "faces detected: $faceCount",
                color = Color.White,
                modifier = Modifier
                    .background(
                        Color.Black.copy(alpha = 0.65f)
                    )
                    .padding(
                        horizontal = 16.dp,
                        vertical = 8.dp
                    )
            )

            if (statusMessage.isNotEmpty()) {
                Text(
                    text = statusMessage,
                    color = Color.White,
                    modifier = Modifier
                        .background(
                            Color.Black.copy(alpha = 0.65f)
                        )
                        .padding(
                            horizontal = 16.dp,
                            vertical = 8.dp
                        )
                )
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Button(
                onClick = {

                    if (faceCount != 1) {
                        statusMessage =
                            "make sure exactly one face is visible"
                        return@Button
                    }

                    val capture = imageCapture

                    if (capture == null) {
                        statusMessage =
                            "camera is not ready yet"
                        return@Button
                    }

                    if (isCapturing) {
                        return@Button
                    }

                    isCapturing = true
                    statusMessage = "capturing..."

                    val file = File(
                        context.cacheDir,
                        "face_sample_${System.currentTimeMillis()}.jpg"
                    )

                    val outputOptions =
                        ImageCapture.OutputFileOptions.Builder(file)
                            .build()

                    capture.takePicture(
                        outputOptions,
                        ContextCompat.getMainExecutor(context),
                        object : ImageCapture.OnImageSavedCallback {

                            override fun onImageSaved(
                                outputFileResults: ImageCapture.OutputFileResults
                            ) {

                                val uri =
                                    Uri.fromFile(file)

                                try {
                                    val capturedImage =
                                        InputImage.fromFilePath(
                                            context,
                                            uri
                                        )

                                    detector.process(capturedImage)
                                        .addOnSuccessListener { faces ->

                                            if (faces.size == 1) {

                                                val updatedSamples =
                                                    capturedSamples +
                                                            file.absolutePath

                                                capturedSamples =
                                                    updatedSamples

                                                statusMessage =
                                                    "sample ${updatedSamples.size} captured"

                                                if (updatedSamples.size == 3) {
                                                    onSamplesComplete(
                                                        updatedSamples
                                                    )
                                                }

                                            } else {

                                                file.delete()

                                                statusMessage =
                                                    "capture failed: exactly one face is required"
                                            }
                                        }
                                        .addOnFailureListener {

                                            file.delete()

                                            statusMessage =
                                                "could not verify the captured face"
                                        }
                                        .addOnCompleteListener {
                                            isCapturing = false
                                        }

                                } catch (_: Exception) {

                                    file.delete()

                                    statusMessage =
                                        "could not process captured image"

                                    isCapturing = false
                                }
                            }

                            override fun onError(
                                exception: ImageCaptureException
                            ) {
                                statusMessage =
                                    "capture failed"

                                isCapturing = false
                            }
                        }
                    )
                }
            ) {
                Text(
                    if (isCapturing) {
                        "capturing..."
                    } else {
                        "capture sample"
                    }
                )
            }

            Button(
                onClick = onBack,
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Text("back")
            }
        }
    }
}

private fun mapFaceBox(
    left: Float,
    top: Float,
    right: Float,
    bottom: Float,
    imageWidth: Float,
    imageHeight: Float,
    viewWidth: Float,
    viewHeight: Float,
): Rect {

    if (
        (imageWidth <= 0f) ||
        (imageHeight <= 0f) ||
        (viewWidth <= 0f) ||
        (viewHeight <= 0f)
    ) {
        return Rect.Zero
    }

    val scale = maxOf(
        viewWidth / imageWidth,
        viewHeight / imageHeight
    )

    val scaledWidth = imageWidth * scale
    val scaledHeight = imageHeight * scale

    val offsetX = (viewWidth - scaledWidth) / 2f
    val offsetY = (viewHeight - scaledHeight) / 2f

    return Rect(
        left = ((left * scale) + offsetX),
        top = ((top * scale) + offsetY),
        right = ((right * scale) + offsetX),
        bottom = ((bottom * scale) + offsetY),
    )
}
