package com.example.smartattendance.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

data class AttendanceRecordWithStudent(
    val recordId: Long,
    val sessionId: Long,
    val studentId: String,
    val studentName: String,
    val status: String,
    val timestamp: Long,
)

data class DetailedAttendanceRecord(
    val recordId: Long,
    val sessionId: Long,
    val studentId: String,
    val studentName: String,
    val status: String,
    val timestamp: Long,
    val className: String,
    val sessionDate: Long,
)

@Dao
interface AttendanceDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(
        session: AttendanceSessionEntity,
    ): Long

    @Query(
        """
        SELECT * FROM attendance_sessions
        ORDER BY createdAt DESC
        """
    )
    suspend fun getAllSessions(): List<AttendanceSessionEntity>

    @Query(
        """
        SELECT * FROM attendance_sessions
        WHERE sessionId = :sessionId
        LIMIT 1
        """
    )
    suspend fun getSessionById(
        sessionId: Long
    ): AttendanceSessionEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertRecord(
        record: AttendanceRecordEntity
    ): Long

    @Update
    suspend fun updateRecord(
        record: AttendanceRecordEntity
    )

    @Query(
        """
        SELECT r.recordId, r.sessionId, r.studentId, s.name as studentName, r.status, r.timestamp
        FROM attendance_records r
        INNER JOIN students s ON r.studentId = s.studentId
        WHERE r.sessionId = :sessionId
        ORDER BY s.name COLLATE NOCASE ASC
        """
    )
    suspend fun getRecordsForSession(
        sessionId: Long
    ): List<AttendanceRecordWithStudent>

    @Query(
        """
        SELECT r.recordId, r.sessionId, r.studentId, s.name as studentName, r.status, r.timestamp, ses.className, ses.createdAt as sessionDate
        FROM attendance_records r
        INNER JOIN students s ON r.studentId = s.studentId
        INNER JOIN attendance_sessions ses ON r.sessionId = ses.sessionId
        WHERE (:sessionId = 0 OR r.sessionId = :sessionId)
          AND (:studentId = '' OR r.studentId = :studentId)
          AND (:startTime = 0 OR r.timestamp >= :startTime)
          AND (:endTime = 0 OR r.timestamp <= :endTime)
        ORDER BY r.timestamp DESC
        """
    )
    suspend fun getFilteredRecords(
        sessionId: Long,
        studentId: String,
        startTime: Long,
        endTime: Long,
    ): List<DetailedAttendanceRecord>

    @Query(
        """
        DELETE FROM attendance_records
        WHERE sessionId = :sessionId AND studentId = :studentId
        """
    )
    suspend fun deleteRecord(
        sessionId: Long,
        studentId: String
    ): Int
}
