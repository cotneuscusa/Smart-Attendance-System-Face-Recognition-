package com.example.smartattendance

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.smartattendance.data.AttendanceDatabase
import com.example.smartattendance.data.AttendanceRecordWithStudent
import com.example.smartattendance.data.AttendanceRepository
import com.example.smartattendance.data.AttendanceSessionEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SessionDetailScreen(
    sessionId: Long,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var session by remember {
        mutableStateOf<AttendanceSessionEntity?>(null)
    }
    var records by remember {
        mutableStateOf<List<AttendanceRecordWithStudent>>(emptyList())
    }
    var errorMessage by remember {
        mutableStateOf("")
    }

    val repository = remember {
        AttendanceRepository(AttendanceDatabase.getInstance(context))
    }

    val coroutineScope = rememberCoroutineScope()

    suspend fun loadData() {
        try {
            val s = withContext(Dispatchers.IO) {
                repository.getSessionById(sessionId)
            }
            val r = withContext(Dispatchers.IO) {
                repository.getRecordsForSession(sessionId)
            }
            session = s
            records = r
            errorMessage = ""
        } catch (exception: Exception) {
            errorMessage = exception.message ?: "failed to load attendance records"
        }
    }

    LaunchedEffect(sessionId) {
        loadData()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
    ) {
        Text(
            text = session?.className ?: "attendance session",
            style = MaterialTheme.typography.headlineMedium,
        )

        Spacer(
            modifier = Modifier.height(8.dp),
        )

        Text(
            text = "total present: ${records.size}",
            style = MaterialTheme.typography.bodyLarge,
        )

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        if (errorMessage.isNotEmpty()) {
            Text(
                text = "error: $errorMessage",
                color = MaterialTheme.colorScheme.error,
            )
            Spacer(
                modifier = Modifier.height(8.dp),
            )
        }

        if (records.isEmpty() && errorMessage.isEmpty()) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text("no attendance recorded yet")
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(
                    items = records,
                    key = { it.recordId },
                ) { record ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                            ) {
                                Text(
                                    text = record.studentName,
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "id: ${record.studentId}",
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "status: ${record.status}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }

                            Button(
                                onClick = {
                                    coroutineScope.launch(Dispatchers.IO) {
                                        repository.deleteRecord(sessionId, record.studentId)
                                        loadData()
                                    }
                                },
                            ) {
                                Text("remove")
                            }
                        }
                    }
                }
            }
        }

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("finish / back to home")
        }
    }
}
