package com.example.smartattendance.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class StudentEntity(
    @PrimaryKey
    val studentId: String,

    val name: String,

    val createdAt: Long = System.currentTimeMillis()
)