package com.example.smartattendance.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface StudentDao {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(student: StudentEntity)

    @Query(
        """
        SELECT * FROM students
        ORDER BY name COLLATE NOCASE ASC
        """
    )
    suspend fun getAllStudents(): List<StudentEntity>

    @Query(
        """
        SELECT * FROM students
        WHERE studentId = :studentId
        LIMIT 1
        """
    )
    suspend fun getStudentById(
        studentId: String
    ): StudentEntity?

    @Query(
        """
        SELECT EXISTS(
            SELECT 1 FROM students
            WHERE studentId = :studentId
        )
        """
    )
    suspend fun studentExists(
        studentId: String
    ): Boolean

    @Query(
        """
        DELETE FROM students
        WHERE studentId = :studentId
        """
    )
    suspend fun deleteStudentById(
        studentId: String
    ): Int
}