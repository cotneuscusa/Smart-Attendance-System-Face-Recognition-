package com.example.smartattendance.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface FaceEmbeddingDao {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAll(
        embeddings: List<FaceEmbeddingEntity>
    )

    @Query(
        """
        SELECT * FROM face_embeddings
        WHERE studentId = :studentId
        ORDER BY sampleIndex ASC
        """
    )
    suspend fun getForStudent(
        studentId: String
    ): List<FaceEmbeddingEntity>

    @Query(
        """
        SELECT COUNT(*) FROM face_embeddings
        WHERE studentId = :studentId
        """
    )
    suspend fun getCountForStudent(
        studentId: String
    ): Int

    @Query(
        """
        DELETE FROM face_embeddings
        WHERE studentId = :studentId
        """
    )
    suspend fun deleteForStudent(
        studentId: String
    ): Int
}
