package com.example.smartattendance.data

class ReportRepository(
    private val database: AttendanceDatabase,
) {
    private val dao = database.attendanceDao()

    suspend fun getFilteredRecords(
        sessionId: Long = 0,
        studentId: String = "",
        startTime: Long = 0,
        endTime: Long = 0,
    ): List<DetailedAttendanceRecord> {
        return dao.getFilteredRecords(
            sessionId = sessionId,
            studentId = studentId,
            startTime = startTime,
            endTime = endTime,
        )
    }

    suspend fun getAllSessions(): List<AttendanceSessionEntity> {
        return dao.getAllSessions()
    }

    suspend fun getAllStudents(): List<StudentEntity> {
        return database.studentDao().getAllStudents()
    }
}
