package com.example.smartattendance.ml

import kotlin.math.sqrt

data class RecognitionResult(
    val studentId: String,
    val studentName: String,
    val similarity: Float,
)

data class RegisteredStudentEmbeddings(
    val studentId: String,
    val studentName: String,
    val embeddings: List<FloatArray>,
)

object FaceMatcher {

    const val MATCH_THRESHOLD = 0.45f

    fun cosineSimilarity(
        embedding1: FloatArray,
        embedding2: FloatArray,
    ): Float {
        require(embedding1.size == embedding2.size) {
            "Embeddings must have the same size."
        }

        var dotProduct = 0f
        var norm1Sq = 0f
        var norm2Sq = 0f

        for (i in embedding1.indices) {
            dotProduct += embedding1[i] * embedding2[i]
            norm1Sq += embedding1[i] * embedding1[i]
            norm2Sq += embedding2[i] * embedding2[i]
        }

        val denom = sqrt(norm1Sq) * sqrt(norm2Sq)
        if (denom <= 0f) {
            return 0f
        }

        return dotProduct / denom
    }

    fun findBestMatch(
        liveEmbedding: FloatArray,
        registeredStudents: List<RegisteredStudentEmbeddings>,
        threshold: Float = MATCH_THRESHOLD,
    ): RecognitionResult? {
        var bestMatch: RecognitionResult? = null
        var maxSimilarity = -1f

        for ((studentId, studentName, embeddings) in registeredStudents) {
            var studentMaxSimilarity = -1f
            for (savedEmbedding in embeddings) {
                val similarity = cosineSimilarity(
                    embedding1 = liveEmbedding,
                    embedding2 = savedEmbedding,
                )
                if (similarity > studentMaxSimilarity) {
                    studentMaxSimilarity = similarity
                }
            }

            if (studentMaxSimilarity > maxSimilarity) {
                maxSimilarity = studentMaxSimilarity
                if (studentMaxSimilarity >= threshold) {
                    bestMatch = RecognitionResult(
                        studentId = studentId,
                        studentName = studentName,
                        similarity = studentMaxSimilarity,
                    )
                }
            }
        }

        if (maxSimilarity < threshold) {
            return null
        }

        return bestMatch
    }
}
