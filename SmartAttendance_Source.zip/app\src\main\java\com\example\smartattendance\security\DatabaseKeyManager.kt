package com.example.smartattendance.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object DatabaseKeyManager {

    private const val KEYSTORE_PROVIDER = "AndroidKeyStore"

    private const val KEY_ALIAS =
        "smart_attendance_database_master_key"

    private const val PREFERENCES_NAME =
        "smart_attendance_database_security"

    private const val ENCRYPTED_PASSPHRASE =
        "encrypted_database_passphrase"

    private const val PASSPHRASE_IV =
        "database_passphrase_iv"

    @Synchronized
    fun getOrCreatePassphrase(
        context: Context,
        databaseName: String
    ): ByteArray {

        val appContext = context.applicationContext

        val preferences = appContext.getSharedPreferences(
            PREFERENCES_NAME,
            Context.MODE_PRIVATE
        )

        val encryptedValue = preferences.getString(
            ENCRYPTED_PASSPHRASE,
            null
        )

        val ivValue = preferences.getString(
            PASSPHRASE_IV,
            null
        )

        if (encryptedValue != null || ivValue != null) {

            require(
                encryptedValue != null && ivValue != null
            ) {
                "Database encryption key data is incomplete."
            }

            val masterKey = loadMasterKey()
                ?: throw IllegalStateException(
                    "The database encryption key is missing."
                )

            val encryptedBytes = Base64.decode(
                encryptedValue,
                Base64.NO_WRAP
            )

            val iv = Base64.decode(
                ivValue,
                Base64.NO_WRAP
            )

            val cipher = Cipher.getInstance(
                "AES/GCM/NoPadding"
            )

            cipher.init(
                Cipher.DECRYPT_MODE,
                masterKey,
                GCMParameterSpec(128, iv)
            )

            return cipher.doFinal(encryptedBytes)
        }

        check(
            !appContext.getDatabasePath(databaseName).exists()
        ) {
            "The database exists, but its saved encryption key is missing."
        }

        val masterKey = getOrCreateMasterKey()

        val passphrase = ByteArray(32)
        SecureRandom().nextBytes(passphrase)

        val cipher = Cipher.getInstance(
            "AES/GCM/NoPadding"
        )

        cipher.init(
            Cipher.ENCRYPT_MODE,
            masterKey
        )

        val encryptedBytes = cipher.doFinal(passphrase)
        val iv = cipher.iv

        val saved = preferences.edit()
            .putString(
                ENCRYPTED_PASSPHRASE,
                Base64.encodeToString(
                    encryptedBytes,
                    Base64.NO_WRAP
                )
            )
            .putString(
                PASSPHRASE_IV,
                Base64.encodeToString(
                    iv,
                    Base64.NO_WRAP
                )
            )
            .commit()

        if (!saved) {
            passphrase.fill(0)

            throw IllegalStateException(
                "Could not save the database encryption key."
            )
        }

        return passphrase
    }

    private fun loadMasterKey(): SecretKey? {

        val keyStore = KeyStore.getInstance(
            KEYSTORE_PROVIDER
        )

        keyStore.load(null)

        return keyStore.getKey(
            KEY_ALIAS,
            null
        ) as? SecretKey
    }

    private fun getOrCreateMasterKey(): SecretKey {

        loadMasterKey()?.let {
            return it
        }

        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            KEYSTORE_PROVIDER
        )

        val specification = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or
                    KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(
                KeyProperties.BLOCK_MODE_GCM
            )
            .setEncryptionPaddings(
                KeyProperties.ENCRYPTION_PADDING_NONE
            )
            .setKeySize(256)
            .build()

        keyGenerator.init(specification)

        return keyGenerator.generateKey()
    }
}