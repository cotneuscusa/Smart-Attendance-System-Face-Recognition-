# Smart Attendance

Smart Attendance is an Android application for managing classroom attendance with on-device face detection and face recognition. Teachers can register students, create class sessions, record attendance through the camera, review or correct records, and export attendance reports as CSV or PDF files.

The project is built with Kotlin and Jetpack Compose. Student profiles, face embeddings, sessions, and attendance records are stored locally on the device.

## Features

### Student registration

* Create student profiles using a name and student ID.
* Capture multiple face samples during registration.
* Use Google ML Kit Face Detection to check for a visible face before processing a sample.
* Convert processed face images into numerical embeddings for later matching.

### Live attendance

* Create an attendance session for a class or course.
* Use the device camera to detect and process faces during the session.
* Match face embeddings against registered students using cosine similarity.
* Automatically record recognized students as present and avoid duplicate attendance records within the same session.
* Treat faces that do not meet the configured matching threshold as unknown rather than assigning them to a student.

### Attendance records and reports

* Browse students, sessions, and attendance records.
* View attendance by session or date.
* Correct records manually when needed.
* Export records to CSV for use in spreadsheet software.
* Generate PDF reports for printing or sharing.
* Save exported reports or share them through Android's system share interface.

### Local data protection

* Store application data in a Room database encrypted with SQLCipher.
* Use Android Keystore-backed key management for the database encryption key.
* Perform face processing on the device rather than sending face data to a remote recognition service.
* Remove temporary registration images after feature extraction, as implemented by the registration flow.

Face embeddings are sensitive biometric data even when they are not raw photographs. Protect the device, restrict access to exported reports, and obtain the appropriate consent before registering or processing anyone's face.

## How Face Recognition Works

1. A teacher registers a student and captures face samples.
2. ML Kit detects the face in each sample.
3. The app preprocesses the detected face and passes it to the MobileFaceNet model bundled with the app.
4. The model produces a 192-value face embedding, which is L2-normalized by the embedding pipeline.
5. During an attendance session, the app repeats the detection and embedding steps for faces in the camera stream.
6. The matching component compares the new embedding with stored embeddings using cosine similarity. The current matching threshold is configured as `0.45f`.
7. A sufficiently close match can be recorded as present for the active session; otherwise, the face is treated as unknown.

Recognition results can vary with lighting, camera quality, head pose, occlusion, preprocessing, and the selected threshold. Test the application in the intended environment and manually review attendance records when necessary. The configured threshold is not a universal guarantee of recognition accuracy.

## Technology Stack

| Area                | Technology                                                                        |
| ------------------- | --------------------------------------------------------------------------------- |
| Language and UI     | Kotlin, Jetpack Compose, Material 3                                               |
| Camera              | CameraX (`camera-camera2`, `camera-lifecycle`, `camera-view`)                     |
| Face detection      | Google ML Kit Face Detection                                                      |
| Face embeddings     | MobileFaceNet with LiteRT / TensorFlow Lite                                       |
| Local database      | Room, AndroidX SQLite, SQLCipher                                                  |
| Key management      | Android Keystore                                                                  |
| Report export       | Android `PdfDocument` API and a CSV exporter                                      |
| Secure file sharing | Android `FileProvider` and the system share interface                             |
| Build configuration | Gradle, with dependency versions managed in `libs.versions.toml` where configured |

## Requirements

* Android Studio with support for the project's Android Gradle Plugin and Kotlin versions.
* Android SDK and the dependencies configured by the project.
* An Android device running Android 6.0 (API 23) or later, or a compatible emulator.
* Camera access for face registration and live attendance.

A physical device is recommended when testing camera performance and recognition behavior in realistic conditions.

## Setup and Run

1. Clone or download this repository.
2. Open the project folder in Android Studio.
3. Allow Gradle sync to finish and resolve the project's dependencies.
4. Connect an Android device with USB debugging enabled, or start an emulator.
5. Grant the requested camera and other runtime permissions when prompted.
6. Select the `app` run configuration and click **Run** in Android Studio.

## Build a Debug APK

From the project root, run the Gradle wrapper.

**Windows PowerShell:**

```powershell
.\gradlew.bat clean assembleDebug
```

**macOS or Linux:**

```bash
./gradlew clean assembleDebug
```

If the build succeeds, the debug APK is generated at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

To install it on a connected Android device with ADB available on your `PATH`:

```bash
adb devices
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

On Windows, if PowerShell does not recognize `adb`, you can call the SDK's executable directly:

```powershell
& "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe" devices
& "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe" install -r ".\app\build\outputs\apk\debug\app-debug.apk"
```

The debug APK is intended for development and testing. If a submission or release requires a signed release build, create and verify that build separately.

## Project Structure

The main application package is `com.example.smartattendance`.

```text
com.example.smartattendance/
├── MainActivity.kt
├── data/
│   ├── AttendanceDatabase
│   ├── StudentEntity
│   ├── FaceEmbeddingEntity
│   ├── AttendanceSessionEntity
│   ├── AttendanceRecordEntity
│   ├── repositories
│   └── EmbeddingCodec
├── export/
│   ├── CsvExporter
│   └── PdfExporter
├── ml/
│   ├── FaceEmbedder
│   ├── FacePreprocessor
│   └── FaceMatcher
└── security/
    └── DatabaseKeyManager
```

The UI package also contains screens for student registration, student and session lists, live attendance, session details, and attendance reports. Exact file names may vary as the project evolves.

## Before Submitting

* Build the project from a clean state and verify that Gradle reports `BUILD SUCCESSFUL`.
* Install the generated APK on a physical device and test the main workflows.
* Check student registration, live attendance, duplicate prevention, manual corrections, date/session filtering, and CSV/PDF exports.
* Confirm that camera permissions and the local database behave correctly after closing and reopening the app.
* Include the source code and any requested screenshots or report files alongside the APK.

## Privacy Note

This application handles student information and biometric-derived data. Use it only with appropriate authorization and consent, follow applicable institutional policies, and avoid sharing the database or exported reports publicly. Local processing and encryption reduce some risks but do not make biometric data risk-free.
