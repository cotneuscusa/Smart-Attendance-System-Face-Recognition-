package com.example.smartattendance

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.smartattendance.data.AttendanceDatabase
import com.example.smartattendance.data.AttendanceRepository
import com.example.smartattendance.data.StudentRepository
import com.example.smartattendance.ml.FaceMatcher
import com.example.smartattendance.ml.FacePreprocessor
import com.example.smartattendance.ml.RegisteredStudentEmbeddings
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

@ExperimentalGetImage
@Composable
fun LiveAttendanceScreen(
    sessionId: Long,
    onViewRecords: () -> Unit,
) {
    val context = LocalContext.current
    val activity = context as ComponentActivity

    var cameraPermissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA,
            ) == PackageManager.PERMISSION_GRANTED,
        )
    }

    var faceCount by remember {
        mutableIntStateOf(0)
    }

    var faceBoxes by remember {
        mutableStateOf<List<Rect>>(emptyList())
    }

    var recognitionStatus by remember {
        mutableStateOf("loading registered students...")
    }

    var matchedStudentName by remember {
        mutableStateOf<String?>(null)
    }

    var matchedStudentId by remember {
        mutableStateOf<String?>(null)
    }

    var markedMessage by remember {
        mutableStateOf("")
    }

    var registeredStudents by remember {
        mutableStateOf<List<RegisteredStudentEmbeddings>>(emptyList())
    }

    var errorMessage by remember {
        mutableStateOf("")
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
    ) { granted ->
        cameraPermissionGranted = granted
    }

    val cameraExecutor = remember {
        Executors.newSingleThreadExecutor()
    }

    val detector = remember {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(
                FaceDetectorOptions.PERFORMANCE_MODE_FAST,
            )
            .setLandmarkMode(
                FaceDetectorOptions.LANDMARK_MODE_NONE,
            )
            .setClassificationMode(
                FaceDetectorOptions.CLASSIFICATION_MODE_NONE,
            )
            .build()

        FaceDetection.getClient(options)
    }

    LaunchedEffect(Unit) {
        try {
            val studentsWithEmbeddings = withContext(Dispatchers.IO) {
                val repository = StudentRepository(
                    AttendanceDatabase.getInstance(context),
                )
                val students = repository.getAllStudents()
                students.map { (studentId, name) ->
                    val embeddings = repository.getEmbeddings(studentId)
                    RegisteredStudentEmbeddings(
                        studentId = studentId,
                        studentName = name,
                        embeddings = embeddings,
                    )
                }
            }

            registeredStudents = studentsWithEmbeddings
            recognitionStatus = if (studentsWithEmbeddings.isEmpty()) {
                "no registered students found"
            } else {
                "position face in camera to mark attendance"
            }
        } catch (exception: Exception) {
            errorMessage = exception.message ?: "failed to load students"
            recognitionStatus = ""
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            cameraExecutor.shutdown()
            detector.close()
        }
    }

    if (!cameraPermissionGranted) {
        LaunchedEffect(Unit) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text("camera permission is required")

            Button(
                onClick = {
                    permissionLauncher.launch(
                        Manifest.permission.CAMERA,
                    )
                },
                modifier = Modifier.padding(top = 16.dp),
            ) {
                Text("allow camera")
            }

            Button(
                onClick = onViewRecords,
                modifier = Modifier.padding(top = 8.dp),
            ) {
                Text("view records")
            }
        }

        return
    }

    Box(
        modifier = Modifier.fillMaxSize(),
    ) {
        AndroidView(
            factory = { currentContext ->
                val previewView = PreviewView(currentContext)
                val cameraProviderFuture =
                    ProcessCameraProvider.getInstance(currentContext)

                cameraProviderFuture.addListener(
                    {
                        val cameraProvider =
                            cameraProviderFuture.get()

                        val preview = Preview.Builder()
                            .build()
                            .also {
                                it.surfaceProvider =
                                    previewView.surfaceProvider
                            }

                        val imageAnalysis =
                            ImageAnalysis.Builder()
                                .setBackpressureStrategy(
                                    ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST,
                                )
                                .build()

                        var lastRecognitionTime = 0L

                        imageAnalysis.setAnalyzer(
                            cameraExecutor,
                        ) { imageProxy ->
                            val mediaImage = imageProxy.image

                            if (mediaImage == null) {
                                imageProxy.close()
                                return@setAnalyzer
                            }

                            val rotation =
                                imageProxy.imageInfo.rotationDegrees

                            val imageWidth =
                                if ((rotation == 0) || (rotation == 180)) {
                                    imageProxy.width
                                } else {
                                    imageProxy.height
                                }

                            val imageHeight =
                                if ((rotation == 0) || (rotation == 180)) {
                                    imageProxy.height
                                } else {
                                    imageProxy.width
                                }

                            val image = InputImage.fromMediaImage(
                                mediaImage,
                                rotation,
                            )

                            detector.process(image)
                                .addOnSuccessListener { faces ->
                                    val boxes = faces.map { face ->
                                        val box = face.boundingBox

                                        mapFaceBox(
                                            left = box.left.toFloat(),
                                            top = box.top.toFloat(),
                                            right = box.right.toFloat(),
                                            bottom = box.bottom.toFloat(),
                                            imageWidth = imageWidth.toFloat(),
                                            imageHeight = imageHeight.toFloat(),
                                            viewWidth = previewView.width.toFloat(),
                                            viewHeight = previewView.height.toFloat(),
                                        )
                                    }

                                    faceCount = faces.size
                                    faceBoxes = boxes

                                    val currentTime = System.currentTimeMillis()
                                    if ((faces.size == 1) &&
                                        registeredStudents.isNotEmpty() &&
                                        ((currentTime - lastRecognitionTime) > 1200)
                                    ) {
                                        lastRecognitionTime = currentTime

                                        try {
                                            val bitmap = imageProxy.toBitmap()
                                            kotlinx.coroutines.CoroutineScope(Dispatchers.Default).launch {
                                                try {
                                                    val croppedBitmap = FacePreprocessor.preprocessBitmap(
                                                        bitmap = bitmap,
                                                        rotationDegrees = rotation,
                                                    )
                                                    try {
                                                        FaceEmbedder(context = currentContext).use { embedder ->
                                                            val embedding = embedder.embed(croppedBitmap)
                                                            val match = FaceMatcher.findBestMatch(
                                                                liveEmbedding = embedding,
                                                                registeredStudents = registeredStudents,
                                                            )

                                                            withContext(Dispatchers.Main) {
                                                                if (match != null) {
                                                                    matchedStudentName = match.studentName
                                                                    matchedStudentId = match.studentId
                                                                    recognitionStatus = "marked present: ${match.studentName}"
                                                                    markedMessage = "marked present: ${match.studentName}"

                                                                    // Save attendance
                                                                    kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                                                                        val attendanceRepo = AttendanceRepository(
                                                                            AttendanceDatabase.getInstance(currentContext),
                                                                        )
                                                                        attendanceRepo.markPresent(
                                                                            sessionId = sessionId,
                                                                            studentId = match.studentId,
                                                                        )
                                                                    }
                                                                } else {
                                                                    matchedStudentName = null
                                                                    matchedStudentId = null
                                                                    recognitionStatus = "unknown student"
                                                                }
                                                            }
                                                        }
                                                    } finally {
                                                        croppedBitmap.recycle()
                                                    }
                                                } catch (_: Exception) {
                                                    withContext(Dispatchers.Main) {
                                                        recognitionStatus = "position face clearly"
                                                    }
                                                }
                                            }
                                        } catch (_: Exception) {
                                            // ignore bitmap conversion errors
                                        }
                                    } else if (faces.size != 1) {
                                        matchedStudentName = null
                                        matchedStudentId = null
                                        if (registeredStudents.isNotEmpty()) {
                                            recognitionStatus = when {
                                                faces.isEmpty() -> "no face detected"
                                                else -> "multiple faces detected"
                                            }
                                        }
                                    }
                                }
                                .addOnFailureListener {
                                    faceCount = 0
                                    faceBoxes = emptyList()
                                }
                                .addOnCompleteListener {
                                    imageProxy.close()
                                }
                        }

                        val cameraSelector =
                            CameraSelector.DEFAULT_FRONT_CAMERA

                        try {
                            cameraProvider.unbindAll()

                            cameraProvider.bindToLifecycle(
                                activity,
                                cameraSelector,
                                preview,
                                imageAnalysis,
                            )
                        } catch (exception: Exception) {
                            exception.printStackTrace()
                        }
                    },
                    ContextCompat.getMainExecutor(currentContext),
                )

                previewView
            },
            modifier = Modifier.fillMaxSize(),
        )

        Canvas(
            modifier = Modifier.fillMaxSize(),
        ) {
            faceBoxes.forEach { box ->
                drawRect(
                    color = if (matchedStudentName != null) Color.Green else Color.Yellow,
                    topLeft = box.topLeft,
                    size = box.size,
                    style = Stroke(
                        width = 6f,
                        cap = StrokeCap.Round,
                    ),
                )
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 40.dp)
                .background(
                    Color.Black.copy(alpha = 0.65f),
                )
                .padding(
                    horizontal = 16.dp,
                    vertical = 10.dp,
                ),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (matchedStudentName != null) {
                Text(
                    text = "present: $matchedStudentName",
                    color = Color.Green,
                    style = MaterialTheme.typography.titleMedium,
                )
                Text(
                    text = "id: $matchedStudentId",
                    color = Color.White,
                )
            } else {
                Text(
                    text = recognitionStatus,
                    color = Color.White,
                )
            }

            if (markedMessage.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = markedMessage,
                    color = Color.Cyan,
                )
            }

            if (errorMessage.isNotEmpty()) {
                Text(
                    text = errorMessage,
                    color = Color.Red,
                )
            }
        }

        Button(
            onClick = onViewRecords,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(24.dp),
        ) {
            Text("view session attendance")
        }
    }
}

private fun mapFaceBox(
    left: Float,
    top: Float,
    right: Float,
    bottom: Float,
    imageWidth: Float,
    imageHeight: Float,
    viewWidth: Float,
    viewHeight: Float,
): Rect {

    if (
        (imageWidth <= 0f) ||
        (imageHeight <= 0f) ||
        (viewWidth <= 0f) ||
        (viewHeight <= 0f)
    ) {
        return Rect.Zero
    }

    val scale = maxOf(
        viewWidth / imageWidth,
        viewHeight / imageHeight,
    )

    val scaledWidth = imageWidth * scale
    val scaledHeight = imageHeight * scale

    val offsetX = (viewWidth - scaledWidth) / 2f
    val offsetY = (viewHeight - scaledHeight) / 2f

    return Rect(
        left = ((left * scale) + offsetX),
        top = ((top * scale) + offsetY),
        right = ((right * scale) + offsetX),
        bottom = ((bottom * scale) + offsetY),
    )
}
