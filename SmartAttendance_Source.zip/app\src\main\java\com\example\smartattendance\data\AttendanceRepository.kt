package com.example.smartattendance.data

class AttendanceRepository(
    private val database: AttendanceDatabase,
) {
    private val dao = database.attendanceDao()

    suspend fun createSession(
        className: String,
    ): Long {
        val cleanName = className.trim()
        require(cleanName.isNotEmpty()) {
            "Class name is required."
        }
        return dao.insertSession(
            AttendanceSessionEntity(
                className = cleanName,
            ),
        )
    }

    suspend fun getAllSessions(): List<AttendanceSessionEntity> {
        return dao.getAllSessions()
    }

    suspend fun getSessionById(
        sessionId: Long,
    ): AttendanceSessionEntity? {
        return dao.getSessionById(sessionId)
    }

    suspend fun markPresent(
        sessionId: Long,
        studentId: String,
    ): Boolean {
        val id = dao.insertRecord(
            AttendanceRecordEntity(
                sessionId = sessionId,
                studentId = studentId,
                status = "PRESENT",
            ),
        )
        return id != -1L
    }

    suspend fun updateRecordStatus(
        recordId: Long,
        sessionId: Long,
        studentId: String,
        status: String,
    ) {
        dao.updateRecord(
            AttendanceRecordEntity(
                recordId = recordId,
                sessionId = sessionId,
                studentId = studentId,
                status = status,
            ),
        )
    }

    suspend fun getRecordsForSession(
        sessionId: Long,
    ): List<AttendanceRecordWithStudent> {
        return dao.getRecordsForSession(sessionId)
    }

    suspend fun deleteRecord(
        sessionId: Long,
        studentId: String,
    ) {
        dao.deleteRecord(sessionId, studentId)
    }
}
