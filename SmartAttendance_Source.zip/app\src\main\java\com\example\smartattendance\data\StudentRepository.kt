package com.example.smartattendance.data

import androidx.room.withTransaction

class StudentRepository(
    private val database: AttendanceDatabase,
) {

    suspend fun registerStudent(
        name: String,
        studentId: String,
        embeddings: List<FloatArray>
    ) {

        val cleanName = name.trim()
        val cleanStudentId = studentId.trim()

        require(cleanName.isNotEmpty()) {
            "Student name is required."
        }

        require(cleanStudentId.isNotEmpty()) {
            "Student ID is required."
        }

        require(embeddings.size >= 3) {
            "At least three face embeddings are required."
        }

        embeddings.forEach { embedding ->
            require(
                embedding.size == EmbeddingCodec.EMBEDDING_SIZE
            ) {
                "A face embedding has an invalid size."
            }

            require(
                embedding.all { it.isFinite() }
            ) {
                "A face embedding contains an invalid value."
            }
        }

        database.withTransaction {

            val studentDao = database.studentDao()

            check(
                studentDao.getStudentById(
                    cleanStudentId
                ) == null
            ) {
                "A student with this ID is already registered."
            }

            studentDao.insert(
                StudentEntity(
                    studentId = cleanStudentId,
                    name = cleanName
                )
            )

            database.faceEmbeddingDao().insertAll(
                embeddings.mapIndexed { index, embedding ->

                    FaceEmbeddingEntity(
                        studentId = cleanStudentId,
                        sampleIndex = index + 1,
                        embedding = EmbeddingCodec.encode(
                            embedding
                        )
                    )
                }
            )
        }
    }

    suspend fun getAllStudents(): List<StudentEntity> {
        return database.studentDao().getAllStudents()
    }

    suspend fun getEmbeddings(
        studentId: String
    ): List<FloatArray> {

        return database.faceEmbeddingDao()
            .getForStudent(studentId)
            .map { entity ->
                EmbeddingCodec.decode(entity.embedding)
            }
    }

    suspend fun getEmbeddingCount(
        studentId: String
    ): Int {
        return database.faceEmbeddingDao().getCountForStudent(studentId)
    }

    suspend fun deleteStudent(
        studentId: String
    ) {
        database.studentDao().deleteStudentById(
            studentId.trim()
        )
    }
}
