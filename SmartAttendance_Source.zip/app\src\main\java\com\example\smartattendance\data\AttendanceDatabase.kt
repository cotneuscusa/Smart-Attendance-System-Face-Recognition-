package com.example.smartattendance.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory
import com.example.smartattendance.security.DatabaseKeyManager

@Database(
    entities = [
        StudentEntity::class,
        FaceEmbeddingEntity::class,
        AttendanceSessionEntity::class,
        AttendanceRecordEntity::class,
    ],
    version = 2,
    exportSchema = false,
)
abstract class AttendanceDatabase : RoomDatabase() {

    abstract fun studentDao(): StudentDao

    abstract fun faceEmbeddingDao(): FaceEmbeddingDao

    abstract fun attendanceDao(): AttendanceDao

    companion object {

        private const val DATABASE_NAME =
            "smart_attendance.db"

        @Volatile
        private var INSTANCE: AttendanceDatabase? = null

        fun getInstance(
            context: Context,
        ): AttendanceDatabase {

            return INSTANCE ?: synchronized(this) {

                INSTANCE ?: buildDatabase(
                    context.applicationContext,
                ).also {
                    INSTANCE = it
                }
            }
        }

        private fun buildDatabase(
            context: Context,
        ): AttendanceDatabase {

            System.loadLibrary("sqlcipher")

            val passphrase =
                DatabaseKeyManager.getOrCreatePassphrase(
                    context = context,
                    databaseName = DATABASE_NAME,
                )

            val factory =
                SupportOpenHelperFactory(passphrase)

            return Room.databaseBuilder(
                context,
                AttendanceDatabase::class.java,
                DATABASE_NAME,
            )
                .openHelperFactory(factory)
                .fallbackToDestructiveMigration(true)
                .build()
        }
    }
}
