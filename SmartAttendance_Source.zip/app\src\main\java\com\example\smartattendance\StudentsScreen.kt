package com.example.smartattendance

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.smartattendance.data.AttendanceDatabase
import com.example.smartattendance.data.StudentEntity
import com.example.smartattendance.data.StudentRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class StudentItem(
    val student: StudentEntity,
    val embeddingCount: Int,
)

@Composable
fun StudentsScreen(
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var studentItems by remember {
        mutableStateOf<List<StudentItem>>(emptyList())
    }
    var errorMessage by remember {
        mutableStateOf("")
    }

    val repository = remember {
        StudentRepository(AttendanceDatabase.getInstance(context))
    }

    val coroutineScope = rememberCoroutineScope()

    suspend fun loadStudents() {
        try {
            val list = withContext(Dispatchers.IO) {
                val students = repository.getAllStudents()
                students.map { student ->
                    val count = repository.getEmbeddingCount(student.studentId)
                    StudentItem(
                        student = student,
                        embeddingCount = count,
                    )
                }
            }
            studentItems = list
            errorMessage = ""
        } catch (exception: Exception) {
            errorMessage = exception.message ?: "Failed to load students"
        }
    }

    LaunchedEffect(Unit) {
        loadStudents()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
    ) {
        Text(
            text = "registered students",
            style = MaterialTheme.typography.headlineMedium,
        )

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        if (errorMessage.isNotEmpty()) {
            Text(
                text = "error: $errorMessage",
                color = MaterialTheme.colorScheme.error,
            )
            Spacer(
                modifier = Modifier.height(8.dp),
            )
        }

        if (studentItems.isEmpty() && errorMessage.isEmpty()) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text("no students registered yet")
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(
                    items = studentItems,
                    key = { studentItem -> studentItem.student.studentId },
                ) { studentItem ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                            ) {
                                Text(
                                    text = studentItem.student.name,
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "id: ${studentItem.student.studentId}",
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "embeddings saved: ${studentItem.embeddingCount} / 3",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (studentItem.embeddingCount == 3) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.error
                                    },
                                )
                            }

                            Button(
                                onClick = {
                                    coroutineScope.launch(Dispatchers.IO) {
                                        repository.deleteStudent(studentItem.student.studentId)
                                        loadStudents()
                                    }
                                },
                            ) {
                                Text("delete")
                            }
                        }
                    }
                }
            }
        }

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("back to home")
        }
    }
}
