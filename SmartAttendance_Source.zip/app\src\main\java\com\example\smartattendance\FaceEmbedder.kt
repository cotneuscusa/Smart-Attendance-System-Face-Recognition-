package com.example.smartattendance

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import org.tensorflow.lite.Interpreter
import java.io.Closeable
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

class FaceEmbedder(
    context: Context,
) : Closeable {

    companion object {
        private const val MODEL_FILE = "MobileFaceNet.tflite"
        private const val INPUT_SIZE = 112
        private const val EMBEDDING_SIZE = 192
        private const val BATCH_SIZE = 2
    }

    private val interpreter: Interpreter

    init {
        val modelBytes = context.assets
            .open(MODEL_FILE)
            .use { inputStream ->
                inputStream.readBytes()
            }

        val modelBuffer = ByteBuffer
            .allocateDirect(modelBytes.size)
            .order(ByteOrder.nativeOrder())

        modelBuffer.put(modelBytes)
        modelBuffer.rewind()

        val options = Interpreter.Options().apply {
            setNumThreads(4)
        }

        interpreter = Interpreter(modelBuffer, options)

        val inputShape = interpreter
            .getInputTensor(0)
            .shape()

        val outputShape = interpreter
            .getOutputTensor(0)
            .shape()

        require(
            inputShape.contentEquals(
                intArrayOf(
                    BATCH_SIZE,
                    INPUT_SIZE,
                    INPUT_SIZE,
                    3,
                )
            )
        ) {
            "unexpected MobileFaceNet input shape: ${inputShape.contentToString()}"
        }

        require(
            outputShape.contentEquals(
                intArrayOf(
                    BATCH_SIZE,
                    EMBEDDING_SIZE,
                )
            )
        ) {
            "unexpected MobileFaceNet output shape: ${outputShape.contentToString()}"
        }
    }

    fun embed(bitmap: Bitmap): FloatArray {

        val resizedBitmap = Bitmap.createScaledBitmap(
            bitmap,
            INPUT_SIZE,
            INPUT_SIZE,
            true,
        )

        val inputSizeInBytes =
            BATCH_SIZE *
                    INPUT_SIZE *
                    INPUT_SIZE *
                    3 *
                    Float.SIZE_BYTES

        val inputBuffer = ByteBuffer
            .allocateDirect(inputSizeInBytes)
            .order(ByteOrder.nativeOrder())

        putBitmapIntoBuffer(
            bitmap = resizedBitmap,
            buffer = inputBuffer,
        )

        putBitmapIntoBuffer(
            bitmap = resizedBitmap,
            buffer = inputBuffer,
        )

        inputBuffer.rewind()

        val output = Array(BATCH_SIZE) {
            FloatArray(EMBEDDING_SIZE)
        }

        interpreter.run(
            inputBuffer,
            output,
        )

        return l2Normalize(output[0])
    }

    private fun putBitmapIntoBuffer(
        bitmap: Bitmap,
        buffer: ByteBuffer,
    ) {
        for (y in 0 until INPUT_SIZE) {
            for (x in 0 until INPUT_SIZE) {

                val pixel = bitmap.getPixel(x, y)

                val red = Color.red(pixel)
                val green = Color.green(pixel)
                val blue = Color.blue(pixel)

                buffer.putFloat(
                    (red - 127.5f) / 127.5f
                )

                buffer.putFloat(
                    (green - 127.5f) / 127.5f
                )

                buffer.putFloat(
                    (blue - 127.5f) / 127.5f
                )
            }
        }
    }

    private fun l2Normalize(
        embedding: FloatArray,
    ): FloatArray {

        var sum = 0.0

        for (value in embedding) {
            sum += value * value
        }

        val norm = sqrt(sum).toFloat()

        if (norm <= 0f) {
            return embedding
        }

        return FloatArray(embedding.size) { index ->
            embedding[index] / norm
        }
    }

    override fun close() {
        interpreter.close()
    }
}