package com.example.smartattendance.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "attendance_records",
    foreignKeys = [
        ForeignKey(
            entity = AttendanceSessionEntity::class,
            parentColumns = ["sessionId"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = StudentEntity::class,
            parentColumns = ["studentId"],
            childColumns = ["studentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["sessionId"]),
        Index(value = ["studentId"]),
        Index(
            value = ["sessionId", "studentId"],
            unique = true
        )
    ]
)
data class AttendanceRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val recordId: Long = 0,

    val sessionId: Long,

    val studentId: String,

    val status: String = "PRESENT",

    val timestamp: Long = System.currentTimeMillis()
)
