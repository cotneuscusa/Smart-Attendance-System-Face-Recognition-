package com.example.smartattendance.ml

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.exifinterface.media.ExifInterface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object FacePreprocessor {

    suspend fun preprocess(
        imagePath: String,
    ): Bitmap {
        val file = File(imagePath)
        require(file.exists()) {
            "Image file does not exist at path: $imagePath"
        }

        val exif = ExifInterface(imagePath)
        val orientation = exif.getAttributeInt(
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.ORIENTATION_NORMAL,
        )

        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
        }

        val baseBitmap = BitmapFactory.decodeFile(imagePath)
            ?: throw IllegalStateException(
                "Could not decode bitmap from path: $imagePath",
            )

        val rotatedBitmap = if (!matrix.isIdentity) {
            val rotated = Bitmap.createBitmap(
                baseBitmap,
                0,
                0,
                baseBitmap.width,
                baseBitmap.height,
                matrix,
                true,
            )
            if (rotated != baseBitmap) {
                baseBitmap.recycle()
            }
            rotated
        } else {
            baseBitmap
        }

        return try {
            preprocessBitmap(
                bitmap = rotatedBitmap,
                rotationDegrees = 0,
            )
        } finally {
            if (rotatedBitmap != baseBitmap) {
                rotatedBitmap.recycle()
            }
        }
    }

    suspend fun preprocessBitmap(
        bitmap: Bitmap,
        rotationDegrees: Int,
    ): Bitmap {
        val matrix = Matrix()
        if (rotationDegrees != 0) {
            matrix.postRotate(rotationDegrees.toFloat())
        }

        val rotatedBitmap = if (!matrix.isIdentity) {
            Bitmap.createBitmap(
                bitmap,
                0,
                0,
                bitmap.width,
                bitmap.height,
                matrix,
                true,
            )
        } else {
            bitmap
        }

        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(
                FaceDetectorOptions.PERFORMANCE_MODE_FAST,
            )
            .setLandmarkMode(
                FaceDetectorOptions.LANDMARK_MODE_NONE,
            )
            .setClassificationMode(
                FaceDetectorOptions.CLASSIFICATION_MODE_NONE,
            )
            .build()

        val detector = FaceDetection.getClient(options)

        try {
            val inputImage = InputImage.fromBitmap(rotatedBitmap, 0)
            val faces = suspendCancellableCoroutine { continuation ->
                detector.process(inputImage)
                    .addOnSuccessListener { faces ->
                        continuation.resume(faces)
                    }
                    .addOnFailureListener { exception ->
                        continuation.resumeWithException(exception)
                    }
            }

            require(faces.size == 1) {
                when {
                    faces.isEmpty() ->
                        throw IllegalStateException("No face detected")
                    else ->
                        throw IllegalStateException("Multiple faces detected")
                }
            }

            val face = faces[0]
            val box = face.boundingBox

            val width = box.width()
            val height = box.height()
            val marginX = (width * 0.2f).toInt()
            val marginY = (height * 0.2f).toInt()

            val left = (box.left - marginX).coerceAtLeast(0)
            val top = (box.top - marginY).coerceAtLeast(0)
            val right = (box.right + marginX).coerceAtMost(rotatedBitmap.width)
            val bottom = (box.bottom + marginY).coerceAtMost(rotatedBitmap.height)

            val cropWidth = (right - left).coerceAtLeast(1)
            val cropHeight = (bottom - top).coerceAtLeast(1)

            return Bitmap.createBitmap(
                rotatedBitmap,
                left,
                top,
                cropWidth,
                cropHeight,
            )

        } finally {
            detector.close()
            if (rotatedBitmap != bitmap) {
                rotatedBitmap.recycle()
            }
        }
    }
}
