package com.example.smartattendance

import android.app.DatePickerDialog
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.smartattendance.data.AttendanceDatabase
import com.example.smartattendance.data.AttendanceSessionEntity
import com.example.smartattendance.data.DetailedAttendanceRecord
import com.example.smartattendance.data.ReportRepository
import com.example.smartattendance.export.CsvExporter
import com.example.smartattendance.export.PdfExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun AttendanceReportScreen(
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var sessions by remember {
        mutableStateOf<List<AttendanceSessionEntity>>(emptyList())
    }
    var selectedSessionId by remember {
        mutableLongStateOf(0L)
    }
    var startTime by remember {
        mutableLongStateOf(0L)
    }
    var endTime by remember {
        mutableLongStateOf(0L)
    }
    var selectedDateStr by remember {
        mutableStateOf("All Dates")
    }
    var records by remember {
        mutableStateOf<List<DetailedAttendanceRecord>>(emptyList())
    }
    var statusMessage by remember {
        mutableStateOf("")
    }
    var errorMessage by remember {
        mutableStateOf("")
    }

    val repository = remember {
        ReportRepository(AttendanceDatabase.getInstance(context))
    }

    val coroutineScope = rememberCoroutineScope()

    suspend fun loadReport(sessionId: Long, start: Long, end: Long) {
        try {
            val list = withContext(Dispatchers.IO) {
                repository.getFilteredRecords(
                    sessionId = sessionId,
                    startTime = start,
                    endTime = end,
                )
            }
            records = list
            errorMessage = ""
        } catch (exception: Exception) {
            errorMessage = exception.message ?: "failed to load report"
        }
    }

    fun shareFile(file: File, mimeType: String) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file,
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "Save or Share Attendance Report")
            context.startActivity(chooser)
        } catch (e: Exception) {
            errorMessage = "Failed to share file: ${e.message}"
        }
    }

    fun showDatePicker() {
        val cal = Calendar.getInstance()
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val selectedCal = Calendar.getInstance().apply {
                    set(year, month, dayOfMonth, 0, 0, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                val start = selectedCal.timeInMillis
                selectedCal.set(Calendar.HOUR_OF_DAY, 23)
                selectedCal.set(Calendar.MINUTE, 59)
                selectedCal.set(Calendar.SECOND, 59)
                selectedCal.set(Calendar.MILLISECOND, 999)
                val end = selectedCal.timeInMillis

                startTime = start
                endTime = end
                selectedDateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(start))

                coroutineScope.launch(Dispatchers.IO) {
                    loadReport(selectedSessionId, start, end)
                }
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH),
        ).show()
    }

    LaunchedEffect(Unit) {
        try {
            val sessionList = withContext(Dispatchers.IO) {
                repository.getAllSessions()
            }
            sessions = sessionList
            loadReport(0L, 0L, 0L)
        } catch (exception: Exception) {
            errorMessage = exception.message ?: "failed to load sessions"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
    ) {
        Text(
            text = "attendance reports",
            style = MaterialTheme.typography.headlineMedium,
        )

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        Text(
            text = "filter by session (${sessions.size} available)",
            style = MaterialTheme.typography.titleSmall,
        )

        Spacer(
            modifier = Modifier.height(8.dp),
        )

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Button(
                    onClick = {
                        selectedSessionId = 0L
                        coroutineScope.launch(Dispatchers.IO) {
                            loadReport(0L, startTime, endTime)
                        }
                    },
                ) {
                    Text(if (selectedSessionId == 0L) "[ All Sessions ]" else "All Sessions")
                }
            }

            items(
                items = sessions,
                key = { (sessionId) -> sessionId },
            ) { (sessionId, className, _) ->
                Button(
                    onClick = {
                        selectedSessionId = sessionId
                        coroutineScope.launch(Dispatchers.IO) {
                            loadReport(sessionId, startTime, endTime)
                        }
                    },
                ) {
                    Text(
                        if (selectedSessionId == sessionId) {
                            "[ $className ]"
                        } else {
                            className
                        },
                    )
                }
            }
        }

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        Text(
            text = "filter by exact date",
            style = MaterialTheme.typography.titleSmall,
        )

        Spacer(
            modifier = Modifier.height(8.dp),
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Button(
                onClick = { showDatePicker() },
                modifier = Modifier.weight(1f),
            ) {
                Text("Date: $selectedDateStr")
            }

            if (startTime > 0L) {
                Button(
                    onClick = {
                        startTime = 0L
                        endTime = 0L
                        selectedDateStr = "All Dates"
                        coroutineScope.launch(Dispatchers.IO) {
                            loadReport(selectedSessionId, 0L, 0L)
                        }
                    },
                    modifier = Modifier.weight(1f),
                ) {
                    Text("Clear Date")
                }
            }
        }

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Button(
                onClick = {
                    coroutineScope.launch(Dispatchers.IO) {
                        try {
                            val file = CsvExporter.exportToCsv(context, records)
                            withContext(Dispatchers.Main) {
                                statusMessage = "CSV generated: ${file.name}"
                                shareFile(file, "text/csv")
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                errorMessage = "CSV export failed: ${e.message}"
                            }
                        }
                    }
                },
                modifier = Modifier.weight(1f),
            ) {
                Text("Export CSV")
            }

            Button(
                onClick = {
                    coroutineScope.launch(Dispatchers.IO) {
                        try {
                            val title = if (selectedSessionId == 0L) {
                                "All Sessions ($selectedDateStr)"
                            } else {
                                "${sessions.find { (id) -> id == selectedSessionId }?.className ?: "Session"} ($selectedDateStr)"
                            }
                            val file = PdfExporter.exportToPdf(context, title, records)
                            withContext(Dispatchers.Main) {
                                statusMessage = "PDF generated: ${file.name}"
                                shareFile(file, "application/pdf")
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                errorMessage = "PDF export failed: ${e.message}"
                            }
                        }
                    }
                },
                modifier = Modifier.weight(1f),
            ) {
                Text("Export PDF")
            }
        }

        if (statusMessage.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = statusMessage,
                color = MaterialTheme.colorScheme.primary,
            )
        }

        if (errorMessage.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "error: $errorMessage",
                color = MaterialTheme.colorScheme.error,
            )
        }

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        Text(
            text = "records found: ${records.size}",
            style = MaterialTheme.typography.bodyMedium,
        )

        Spacer(
            modifier = Modifier.height(8.dp),
        )

        if (records.isEmpty()) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text("no attendance records found")
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(
                    items = records,
                    key = { (recordId) -> recordId },
                ) { (_, _, studentId, studentName, status, timestamp, className, _) ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                        ) {
                            Text(
                                text = studentName,
                                style = MaterialTheme.typography.titleMedium,
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "id: $studentId • class: $className",
                                style = MaterialTheme.typography.bodyMedium,
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(timestamp))
                            Text(
                                text = "time: $dateStr • status: $status",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                }
            }
        }

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("back to home")
        }
    }
}
