package com.example.smartattendance.data

import java.nio.ByteBuffer
import java.nio.ByteOrder

object EmbeddingCodec {

    const val EMBEDDING_SIZE = 192

    fun encode(
        embedding: FloatArray
    ): ByteArray {

        require(
            embedding.size == EMBEDDING_SIZE
        ) {
            "Expected an embedding with $EMBEDDING_SIZE values."
        }

        val buffer = ByteBuffer
            .allocate(embedding.size * Float.SIZE_BYTES)
            .order(ByteOrder.LITTLE_ENDIAN)

        embedding.forEach { value ->
            buffer.putFloat(value)
        }

        return buffer.array()
    }

    fun decode(
        bytes: ByteArray
    ): FloatArray {

        require(
            bytes.size == EMBEDDING_SIZE * Float.SIZE_BYTES
        ) {
            "The stored embedding has an invalid size."
        }

        val buffer = ByteBuffer
            .wrap(bytes)
            .order(ByteOrder.LITTLE_ENDIAN)

        return FloatArray(EMBEDDING_SIZE) {
            buffer.float
        }
    }
}