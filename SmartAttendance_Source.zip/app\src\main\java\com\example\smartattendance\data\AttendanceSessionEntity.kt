package com.example.smartattendance.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "attendance_sessions")
data class AttendanceSessionEntity(
    @PrimaryKey(autoGenerate = true)
    val sessionId: Long = 0,

    val className: String,

    val createdAt: Long = System.currentTimeMillis()
)
