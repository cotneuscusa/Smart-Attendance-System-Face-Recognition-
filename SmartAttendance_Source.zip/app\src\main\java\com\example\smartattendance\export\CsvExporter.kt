package com.example.smartattendance.export

import android.content.Context
import com.example.smartattendance.data.DetailedAttendanceRecord
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CsvExporter {

    fun exportToCsv(
        context: Context,
        records: List<DetailedAttendanceRecord>,
    ): File {
        val file = File(
            context.cacheDir,
            "attendance_report_${System.currentTimeMillis()}.csv",
        )

        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

        file.printWriter().use { out ->
            out.println("Student ID,Student Name,Class / Session,Status,Timestamp")
            records.forEach { (_, _, studentId, studentName, status, timestamp, className, _) ->
                val dateStr = dateFormat.format(Date(timestamp))
                val escapedName = "\"${studentName.replace("\"", "\"\"")}\""
                val escapedClass = "\"${className.replace("\"", "\"\"")}\""
                out.println("$studentId,$escapedName,$escapedClass,$status,$dateStr")
            }
        }

        return file
    }
}
