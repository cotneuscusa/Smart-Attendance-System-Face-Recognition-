package com.example.smartattendance

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.smartattendance.data.AttendanceDatabase
import com.example.smartattendance.data.StudentRepository
import com.example.smartattendance.ml.FacePreprocessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun EmbeddingTestScreen(
    studentName: String,
    studentId: String,
    samplePaths: List<String>,
    onContinue: () -> Unit,
) {
    val appContext = LocalContext.current

    var status by remember {
        mutableStateOf("processing face samples and registering student...")
    }

    var successMessage by remember {
        mutableStateOf("")
    }

    var errorMessage by remember {
        mutableStateOf("")
    }

    LaunchedEffect(samplePaths) {

        try {
            val embeddings = withContext(Dispatchers.Default) {
                FaceEmbedder(context = appContext).use { embedder ->
                    samplePaths.map { path ->
                        val croppedFaceBitmap = FacePreprocessor.preprocess(
                            imagePath = path,
                        )
                        try {
                            embedder.embed(croppedFaceBitmap)
                        } finally {
                            croppedFaceBitmap.recycle()
                        }
                    }
                }
            }

            val repository = StudentRepository(
                database = AttendanceDatabase.getInstance(appContext),
            )

            withContext(Dispatchers.IO) {
                repository.registerStudent(
                    name = studentName,
                    studentId = studentId,
                    embeddings = embeddings,
                )
            }

            status = ""
            successMessage = "student registered successfully"

        } catch (exception: Exception) {

            status = ""

            errorMessage =
                exception.message
                    ?: "unknown registration error"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {

        Text(
            text = "student registration",
            style = MaterialTheme.typography.headlineMedium,
        )

        Spacer(
            modifier = Modifier.height(24.dp),
        )

        Text(
            text = "student: $studentName",
        )

        Spacer(
            modifier = Modifier.height(8.dp),
        )

        Text(
            text = "student id: $studentId",
        )

        Spacer(
            modifier = Modifier.height(24.dp),
        )

        if (status.isNotEmpty()) {
            Text(
                text = status,
            )
        }

        if (successMessage.isNotEmpty()) {

            Spacer(
                modifier = Modifier.height(16.dp),
            )

            Text(
                text = successMessage,
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.titleMedium,
            )
        }

        if (errorMessage.isNotEmpty()) {

            Spacer(
                modifier = Modifier.height(16.dp),
            )

            Text(
                text = "error: $errorMessage",
                color = MaterialTheme.colorScheme.error,
            )
        }

        Spacer(
            modifier = Modifier.height(32.dp),
        )

        Button(
            onClick = onContinue,
        ) {
            Text("continue")
        }
    }
}
