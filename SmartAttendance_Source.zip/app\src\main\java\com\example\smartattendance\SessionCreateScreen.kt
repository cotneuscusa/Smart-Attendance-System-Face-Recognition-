package com.example.smartattendance

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.smartattendance.data.AttendanceDatabase
import com.example.smartattendance.data.AttendanceRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SessionCreateScreen(
    onSessionCreated: (Long) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var className by remember {
        mutableStateOf("")
    }
    var errorMessage by remember {
        mutableStateOf("")
    }
    var isStarting by remember {
        mutableStateOf(value = false)
    }

    val coroutineScope = rememberCoroutineScope()
    val repository = remember {
        AttendanceRepository(AttendanceDatabase.getInstance(context))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = "start attendance session",
            style = MaterialTheme.typography.headlineMedium,
        )

        Spacer(
            modifier = Modifier.height(24.dp),
        )

        OutlinedTextField(
            value = className,
            onValueChange = {
                className = it
                errorMessage = ""
            },
            label = {
                Text("class or course name (e.g. Algorithms - Group 2)")
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        if (errorMessage.isNotEmpty()) {
            Text(
                text = errorMessage,
                color = MaterialTheme.colorScheme.error,
            )
            Spacer(
                modifier = Modifier.height(16.dp),
            )
        }

        Button(
            onClick = {
                val cleanName = className.trim()
                if (cleanName.isEmpty()) {
                    errorMessage = "class name is required"
                    return@Button
                }

                isStarting = true
                coroutineScope.launch(Dispatchers.IO) {
                    try {
                        val sessionId = repository.createSession(cleanName)
                        withContext(Dispatchers.Main) {
                            onSessionCreated(sessionId)
                        }
                    } catch (exception: Exception) {
                        withContext(Dispatchers.Main) {
                            errorMessage = exception.message ?: "failed to create session"
                            isStarting = false
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isStarting,
        ) {
            Text(if (isStarting) "starting..." else "start live attendance")
        }

        Spacer(
            modifier = Modifier.height(12.dp),
        )

        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("back")
        }
    }
}
