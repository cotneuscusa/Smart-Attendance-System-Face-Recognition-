package com.example.smartattendance.export

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import com.example.smartattendance.data.DetailedAttendanceRecord
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfExporter {

    fun exportToPdf(
        context: Context,
        title: String,
        records: List<DetailedAttendanceRecord>,
    ): File {
        val file = File(
            context.cacheDir,
            "attendance_report_${System.currentTimeMillis()}.pdf",
        )

        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val paint = Paint().apply {
            textSize = 12f
            color = Color.BLACK
        }

        val titlePaint = Paint().apply {
            textSize = 18f
            isFakeBoldText = true
            color = Color.BLACK
        }

        var y = 40f
        canvas.drawText("Smart Attendance Report", 40f, y, titlePaint)
        y += 25f
        canvas.drawText("Filter: $title", 40f, y, paint)
        y += 25f
        canvas.drawText("Generated: ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())}", 40f, y, paint)
        y += 35f

        canvas.drawText("Student ID", 40f, y, paint)
        canvas.drawText("Name", 140f, y, paint)
        canvas.drawText("Class", 300f, y, paint)
        canvas.drawText("Status", 450f, y, paint)
        y += 8f
        canvas.drawLine(40f, y, 555f, y, paint)
        y += 20f

        records.forEach { (_, _, studentId, studentName, status, _, className, _) ->
            canvas.drawText(studentId, 40f, y, paint)
            canvas.drawText(studentName.take(20), 140f, y, paint)
            canvas.drawText(className.take(15), 300f, y, paint)
            canvas.drawText(status, 450f, y, paint)
            y += 20f
        }

        document.finishPage(page)

        file.outputStream().use { outputStream ->
            document.writeTo(outputStream)
        }
        document.close()

        return file
    }
}
