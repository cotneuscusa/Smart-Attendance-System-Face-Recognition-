package com.example.smartattendance

import android.content.Intent
import androidx.core.content.FileProvider
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.smartattendance.data.AttendanceDatabase
import com.example.smartattendance.data.AttendanceRecordWithStudent
import com.example.smartattendance.data.AttendanceRepository
import com.example.smartattendance.data.AttendanceSessionEntity
import com.example.smartattendance.data.DetailedAttendanceRecord
import com.example.smartattendance.data.StudentRepository
import com.example.smartattendance.export.CsvExporter
import com.example.smartattendance.export.PdfExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SessionReportDetailScreen(
    sessionId: Long,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var session by remember {
        mutableStateOf<AttendanceSessionEntity?>(null)
    }
    var records by remember {
        mutableStateOf<List<AttendanceRecordWithStudent>>(emptyList())
    }
    var totalStudents by remember {
        mutableIntStateOf(0)
    }
    var statusMessage by remember {
        mutableStateOf("")
    }
    var errorMessage by remember {
        mutableStateOf("")
    }

    val repository = remember {
        AttendanceRepository(AttendanceDatabase.getInstance(context))
    }

    val studentRepository = remember {
        StudentRepository(AttendanceDatabase.getInstance(context))
    }

    val coroutineScope = rememberCoroutineScope()

    suspend fun loadData() {
        try {
            val s = withContext(Dispatchers.IO) {
                repository.getSessionById(sessionId)
            }
            val r = withContext(Dispatchers.IO) {
                repository.getRecordsForSession(sessionId)
            }
            val students = withContext(Dispatchers.IO) {
                studentRepository.getAllStudents()
            }
            session = s
            records = r
            totalStudents = students.size
            errorMessage = ""
        } catch (exception: Exception) {
            errorMessage = exception.message ?: "failed to load session details"
        }
    }

    fun shareFile(file: File, mimeType: String) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file,
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "Save or Share Session Report")
            context.startActivity(chooser)
        } catch (e: Exception) {
            errorMessage = "Failed to share file: ${e.message}"
        }
    }

    LaunchedEffect(sessionId) {
        loadData()
    }

    val attendancePercentage = if (totalStudents > 0) {
        (records.size.toFloat() / totalStudents.toFloat()) * 100f
    } else {
        0f
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
    ) {
        Text(
            text = session?.className ?: "session report",
            style = MaterialTheme.typography.headlineMedium,
        )

        Spacer(
            modifier = Modifier.height(8.dp),
        )

        Text(
            text = "present: ${records.size} / $totalStudents (${String.format(Locale.getDefault(), "%.1f", attendancePercentage)}% attendance)",
            style = MaterialTheme.typography.bodyLarge,
        )

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Button(
                onClick = {
                    coroutineScope.launch(Dispatchers.IO) {
                        try {
                            val detailed = records.map { (recordId, sId, studentId, studentName, status, timestamp) ->
                                DetailedAttendanceRecord(
                                    recordId = recordId,
                                    sessionId = sId,
                                    studentId = studentId,
                                    studentName = studentName,
                                    status = status,
                                    timestamp = timestamp,
                                    className = session?.className ?: "Session",
                                    sessionDate = session?.createdAt ?: timestamp,
                                )
                            }
                            val file = CsvExporter.exportToCsv(context, detailed)
                            withContext(Dispatchers.Main) {
                                statusMessage = "CSV generated: ${file.name}"
                                shareFile(file, "text/csv")
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                errorMessage = "CSV export failed: ${e.message}"
                            }
                        }
                    }
                },
                modifier = Modifier.weight(1f),
            ) {
                Text("Export CSV")
            }

            Button(
                onClick = {
                    coroutineScope.launch(Dispatchers.IO) {
                        try {
                            val detailed = records.map { (recordId, sId, studentId, studentName, status, timestamp) ->
                                DetailedAttendanceRecord(
                                    recordId = recordId,
                                    sessionId = sId,
                                    studentId = studentId,
                                    studentName = studentName,
                                    status = status,
                                    timestamp = timestamp,
                                    className = session?.className ?: "Session",
                                    sessionDate = session?.createdAt ?: timestamp,
                                )
                            }
                            val title = "${session?.className ?: "Session"} - ${String.format(Locale.getDefault(), "%.1f", attendancePercentage)}% Present"
                            val file = PdfExporter.exportToPdf(context, title, detailed)
                            withContext(Dispatchers.Main) {
                                statusMessage = "PDF generated: ${file.name}"
                                shareFile(file, "application/pdf")
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                errorMessage = "PDF export failed: ${e.message}"
                            }
                        }
                    }
                },
                modifier = Modifier.weight(1f),
            ) {
                Text("Export PDF")
            }
        }

        if (statusMessage.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = statusMessage,
                color = MaterialTheme.colorScheme.primary,
            )
        }

        if (errorMessage.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "error: $errorMessage",
                color = MaterialTheme.colorScheme.error,
            )
        }

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        if (records.isEmpty() && errorMessage.isEmpty()) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text("no attendance recorded for this session yet (0.0% attendance)")
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(
                    items = records,
                    key = { (recordId) -> recordId },
                ) { (_, _, studentId, studentName, status, timestamp) ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                            ) {
                                Text(
                                    text = studentName,
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "id: $studentId",
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(timestamp))
                                Text(
                                    text = "time: $dateStr • status: $status",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }

                            Button(
                                onClick = {
                                    coroutineScope.launch(Dispatchers.IO) {
                                        repository.deleteRecord(sessionId, studentId)
                                        loadData()
                                    }
                                },
                            ) {
                                Text("remove")
                            }
                        }
                    }
                }
            }
        }

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("back to sessions")
        }
    }
}
