package com.example.smartattendance

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.smartattendance.ui.theme.SmartAttendanceTheme

class MainActivity : ComponentActivity() {

    @androidx.camera.core.ExperimentalGetImage
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SmartAttendanceTheme {
                SmartAttendanceApp()
            }
        }
    }
}

@androidx.camera.core.ExperimentalGetImage
@Composable
fun SmartAttendanceApp() {

    var currentScreen by remember {
        mutableStateOf("home")
    }

    var studentName by remember {
        mutableStateOf("")
    }

    var studentId by remember {
        mutableStateOf("")
    }

    var capturedSamplePaths by remember {
        mutableStateOf<List<String>>(emptyList())
    }

    var currentSessionId by remember {
        mutableLongStateOf(0L)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
    ) { innerPadding ->

        when (currentScreen) {

            "home" -> {
                HomeScreen(
                    modifier = Modifier.padding(innerPadding),
                    onRegisterStudent = {
                        currentScreen = "registerForm"
                    },
                    onTakeAttendance = {
                        currentScreen = "sessionCreate"
                    },
                    onAttendanceRecords = {
                        currentScreen = "records"
                    },
                    onReports = {
                        currentScreen = "reports"
                    },
                ) {
                    currentScreen = "students"
                }
            }

            "registerForm" -> {
                RegistrationScreen(
                    onStartCapture = { name, id ->
                        studentName = name
                        studentId = id
                        capturedSamplePaths = emptyList()
                        currentScreen = "registerCamera"
                    },
                ) {
                    currentScreen = "home"
                }
            }

            "registerCamera" -> {
                CameraScreen(
                    studentName = studentName,
                    studentId = studentId,
                    onSamplesComplete = { paths ->
                        capturedSamplePaths = paths
                        currentScreen = "registrationComplete"
                    },
                ) {
                    currentScreen = "registerForm"
                }
            }

            "registrationComplete" -> {
                EmbeddingTestScreen(
                    studentName = studentName,
                    studentId = studentId,
                    samplePaths = capturedSamplePaths,
                ) {
                    currentScreen = "home"
                }
            }

            "students" -> {
                StudentsScreen {
                    currentScreen = "home"
                }
            }

            "sessionCreate" -> {
                SessionCreateScreen(
                    onSessionCreated = { sessionId ->
                        currentSessionId = sessionId
                        currentScreen = "liveAttendance"
                    },
                ) {
                    currentScreen = "home"
                }
            }

            "liveAttendance" -> {
                LiveAttendanceScreen(
                    sessionId = currentSessionId,
                ) {
                    currentScreen = "sessionDetail"
                }
            }

            "sessionDetail" -> {
                SessionDetailScreen(
                    sessionId = currentSessionId,
                ) {
                    currentScreen = "home"
                }
            }

            "records" -> {
                SessionsScreen(
                    onSessionSelected = { sessionId ->
                        currentSessionId = sessionId
                        currentScreen = "sessionReportDetail"
                    },
                ) {
                    currentScreen = "home"
                }
            }

            "sessionReportDetail" -> {
                SessionReportDetailScreen(
                    sessionId = currentSessionId,
                ) {
                    currentScreen = "records"
                }
            }

            "reports" -> {
                AttendanceReportScreen {
                    currentScreen = "home"
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    onRegisterStudent: () -> Unit,
    onTakeAttendance: () -> Unit,
    onAttendanceRecords: () -> Unit,
    onReports: () -> Unit,
    onViewStudents: () -> Unit,
) {

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {

        Text(
            text = "smart attendance",
            style = MaterialTheme.typography.headlineLarge,
        )

        Spacer(
            modifier = Modifier.height(32.dp),
        )

        Button(
            onClick = onRegisterStudent,
        ) {
            Text("register student")
        }

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        Button(
            onClick = onTakeAttendance,
        ) {
            Text("take attendance")
        }

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        Button(
            onClick = onAttendanceRecords,
        ) {
            Text("attendance records")
        }

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        Button(
            onClick = onReports,
        ) {
            Text("reports")
        }

        Spacer(
            modifier = Modifier.height(16.dp),
        )

        Button(
            onClick = onViewStudents,
        ) {
            Text("registered students")
        }
    }
}
